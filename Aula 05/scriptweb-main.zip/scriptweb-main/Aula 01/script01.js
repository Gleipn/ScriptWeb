//POO - Programação oritentada a objetos.
//O que seria essa tal POO?
//O que seria um objeto? - Objeto pode ser qualquer coisa.
//O que os objetos tem em comum? Caracteristicas.
//Quais são os pilares de um POO? - Classe, atributos, metodos, encapsulamentos, polimorfismoe e herança
//O que é uma classe? - é um molde (Costureira)
//O que são Atributos = Varáveis? - Carcterísticas do molde (Variáveis metidas)
//O que são métodos = functions? - São ações.


class Cliente{
  nome;
  sobreNome;
  _cpf; //Atributo privado

  comprar(){}

}




