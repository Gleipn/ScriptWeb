//Vou desenvolver minha aplicação

//Fora da classe - Instacia
//Desenvolvendo app

import { Calculadora } from "./calculadora.js";

const calculadoraUm = new Calculadora(23, 43);

console.log(calculadoraUm.soma());
console.log(calculadoraUm.subtracao());
console.log(calculadoraUm.multiplicar());
console.log(calculadoraUm.divisao());